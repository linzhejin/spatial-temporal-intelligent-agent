import json
import sys
from pathlib import Path

import networkx as nx
import pytest
from shapely import wkt

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from spatial.course_fusion import apply_course_junction_overrides, fuse_network


def _feature(source_id, coordinates, *, row=0, name=None, road_class="pedestrian"):
    return {
        "type": "Feature",
        "id": source_id,
        "geometry": {"type": "LineString", "coordinates": coordinates},
        "properties": {
            "source_id": source_id,
            "source_row": row,
            "name": name,
            "road_class": road_class,
            "road_class_raw": road_class,
            "surface": "concrete",
            "surface_raw": "水泥路面",
            "lane_count": 0,
            "geographic_code": 620,
            "raw_source_properties": {"Shape_Leng": 10.0},
        },
    }


def _matched_report(source_id, edge_ids):
    return {"matches": [{
        "source_id": source_id,
        "action": "matched",
        "candidates": [{"candidate_id": "track-1", "edge_ids": edge_ids}],
    }]}


def _new_report(features):
    return {"matches": [{
        "source_id": feature["properties"]["source_id"],
        "action": "new_candidate",
        "candidates": [],
    } for feature in features]}


def _base_graph():
    graph = nx.MultiDiGraph()
    graph.add_node(1, x=114.360, y=30.530)
    graph.add_node(2, x=114.361, y=30.530)
    graph.add_edge(1, 2, key=0, osmid=10, highway="residential", length=95.0,
                   geometry="LINESTRING (114.36 30.53, 114.361 30.53)")
    graph.add_edge(2, 1, key=0, osmid=10, highway="residential", length=95.0,
                   geometry="LINESTRING (114.361 30.53, 114.36 30.53)")
    return graph


def test_matched_course_geometry_adds_walk_variant_without_changing_osm_lineage():
    graph = _base_graph()
    feature = _feature("course:matched", [
        [114.360, 30.530005], [114.3605, 30.530003], [114.361, 30.530005],
    ], name="玉兰路")

    fused, migration = fuse_network(
        graph, [feature], _matched_report("course:matched", [["1", "2", 0], ["2", "1", 0]])
    )

    forward_osm = wkt.loads(fused[1][2][0]["geometry"])
    reverse_osm = wkt.loads(fused[2][1][0]["geometry"])
    forward_key = next(key for key, data in fused[1][2].items()
                       if data.get("course_geometry_replaced"))
    reverse_key = next(key for key, data in fused[2][1].items()
                       if data.get("course_geometry_replaced"))
    forward = wkt.loads(fused[1][2][forward_key]["geometry"])
    reverse = wkt.loads(fused[2][1][reverse_key]["geometry"])
    assert list(forward_osm.coords) == [(114.36, 30.53), (114.361, 30.53)]
    assert list(reverse_osm.coords) == list(reversed(forward_osm.coords))
    assert len(forward.coords) == 3
    assert abs(forward.coords[0][0] - 114.360) < 1e-9
    assert abs(forward.coords[0][1] - 30.530) < 1e-9
    assert forward.coords[1][1] < 30.530005
    assert list(reverse.coords) == list(reversed(forward.coords))
    assert fused[1][2][forward_key]["name"] == "玉兰路"
    assert fused[1][2][forward_key]["osmid"] == 10
    assert fused[1][2][forward_key]["course_road_class"] == "pedestrian"
    replacement_ids = migration["course_feature_dispositions"][0]["geometry_replaced_edges"]
    assert ["1", "2", forward_key] in replacement_ids
    disposition = next(row for row in migration["old_edge_dispositions"]
                       if row["edge_id"] == ["1", "2", 0])
    assert disposition["disposition"] == "retained_osm_with_walk_only_course_variant"
    assert disposition["replacement_edge_ids"] == [["1", "2", forward_key]]


def test_matched_course_geometry_is_walk_only_and_preserves_osm_geometry_for_other_modes():
    graph = _base_graph()
    original_geometry = graph[1][2][0]["geometry"]
    graph[1][2][0]["bicycle"] = "yes"
    graph[1][2][0]["motor_vehicle"] = "yes"
    graph[2][1][0]["bicycle"] = "yes"
    graph[2][1][0]["motor_vehicle"] = "yes"
    feature = _feature("course:mode-isolation", [
        [114.360, 30.530005], [114.3605, 30.530003], [114.361, 30.530005],
    ], name="玉兰路")

    fused, _ = fuse_network(
        graph, [feature], _matched_report(
            "course:mode-isolation", [["1", "2", 0], ["2", "1", 0]]
        )
    )

    from spatial.routing import filter_graph_for_mode

    course_forward = [
        data for _, _, _, data in fused.edges(keys=True, data=True)
        if "course:mode-isolation" in data.get("course_source_ids", [])
        and data.get("course_geometry_replaced")
    ]
    assert course_forward
    assert all(json.loads(edge["allowed_modes"]) == ["walk"] for edge in course_forward)
    assert fused[1][2][0]["geometry"] == original_geometry

    for mode in ("bike", "drive"):
        filtered, _, _ = filter_graph_for_mode(fused, mode)
        assert filtered[1][2][0]["geometry"] == original_geometry
        assert not any(
            "course:mode-isolation" in data.get("course_source_ids", [])
            for _, _, _, data in filtered.edges(keys=True, data=True)
        )

    walk, _, _ = filter_graph_for_mode(fused, "walk")
    assert any(
        "course:mode-isolation" in data.get("course_source_ids", [])
        for _, _, _, data in walk.edges(keys=True, data=True)
    )


def test_unique_match_applies_course_static_attributes_when_geometry_tolerance_fails():
    graph = _base_graph()
    old_geometry = graph[1][2][0]["geometry"]
    feature = _feature("course:static-only", [
        [114.360, 30.53003], [114.361, 30.53003],
    ], name="课程道路", road_class="motor_vehicle")
    report = _matched_report("course:static-only", [["1", "2", 0], ["2", "1", 0]])
    report["matches"][0]["evidence"] = {
        "candidate_count": 1,
        "coverage": 1.0,
        "median_distance_m": 3.2,
        "p95_distance_m": 3.3,
        "direction_difference_deg": 0.0,
        "grade_separation_conflict": False,
    }

    fused, migration = fuse_network(graph, [feature], report)

    assert fused[1][2][0]["geometry"] == old_geometry
    assert fused[1][2][0]["name"] == "课程道路"
    assert fused[1][2][0]["course_road_class"] == "motor_vehicle"
    assert "course_geometry_replaced" not in fused[1][2][0]
    disposition = migration["course_feature_dispositions"][0]
    assert disposition["geometry_replaced_edges"] == []
    assert disposition["attributes_applied_edges"]
    assert disposition["active_release"] is True
    assert disposition["reason"] == "course_static_attributes_applied_geometry_retained"


def test_conflicting_course_static_values_do_not_overwrite_one_another_by_order():
    graph = _base_graph()
    original_geometry = graph[1][2][0]["geometry"]
    features = [
        _feature("course:conflict-a", [[114.360, 30.53003], [114.361, 30.53003]],
                 row=7, name="课程名甲"),
        _feature("course:conflict-b", [[114.360, 30.53003], [114.361, 30.53003]],
                 row=8, name="课程名乙"),
    ]
    report = {"matches": []}
    for feature in features:
        report["matches"].append({
            "source_id": feature["properties"]["source_id"],
            "action": "matched",
            "candidates": [{"candidate_id": "same-edge", "edge_ids": [["1", "2", 0]]}],
            "evidence": {"candidate_count": 1, "coverage": 1.0,
                         "median_distance_m": 3.2, "p95_distance_m": 3.3,
                         "direction_difference_deg": 0.0},
        })

    fused, migration = fuse_network(graph, features, report)

    assert fused[1][2][0]["geometry"] == original_geometry
    assert "course_source_ids" not in fused[1][2][0]
    rows = {row["source_id"]: row for row in migration["course_feature_dispositions"]}
    assert all(row.get("attribute_conflict_edges") for row in rows.values())
    assert all(row["active_release"] is False for row in rows.values())


def test_geometry_replacement_keeps_course_provenance_when_static_values_conflict():
    graph = _base_graph()
    features = [
        _feature("course:geometry", [
            [114.360, 30.530005], [114.361, 30.530005],
        ], row=9, name="课程名甲"),
        _feature("course:static-conflict", [
            [114.360, 30.53003], [114.361, 30.53003],
        ], row=10, name="课程名乙"),
    ]
    report = {"matches": []}
    for feature in features:
        report["matches"].append({
            "source_id": feature["properties"]["source_id"],
            "action": "matched",
            "candidates": [{"candidate_id": "same-edge", "edge_ids": [["1", "2", 0]]}],
            "evidence": {"candidate_count": 1, "coverage": 1.0,
                         "median_distance_m": 3.2, "p95_distance_m": 3.3,
                         "direction_difference_deg": 0.0},
        })

    fused, migration = fuse_network(graph, features, report)

    edge = next(data for data in fused[1][2].values()
                if data.get("course_geometry_replaced"))
    assert edge["course_geometry_replaced"] is True
    assert edge["course_source_ids"] == ["course:geometry"]
    assert edge["course_geometry_source"] == "WHU coursework"
    assert "name" not in edge
    assert migration["course_feature_dispositions"][0]["geometry_replaced_edges"]
    assert migration["course_feature_dispositions"][1].get("attribute_conflict_edges")


def test_new_course_t_junction_splits_old_edges_and_keeps_routes_connected():
    graph = _base_graph()
    graph.add_node(3, x=114.3605, y=30.5305)
    feature = _feature("course:t-connector", [
        [114.3605, 30.530], [114.3605, 30.5305],
    ], row=1)

    fused, migration = fuse_network(graph, [feature], _new_report([feature]))

    assert fused.number_of_edges() == 6
    assert nx.has_path(fused, 1, 3)
    assert nx.has_path(fused, 3, 2)
    course_edges = [data for _, _, data in fused.edges(data=True)
                    if data.get("course_source_id") == "course:t-connector"]
    assert len(course_edges) == 2
    assert all(json.loads(data["allowed_modes"]) == ["walk"] for data in course_edges)
    assert migration["course_feature_dispositions"][0]["active_release"] is True
    assert any(row["disposition"] == "split" for row in migration["old_edge_dispositions"])
    assert len(migration["old_edge_dispositions"]) == graph.number_of_edges()
    split_edges = [(u, v, data) for u, v, data in fused.edges(data=True)
                   if data.get("edge_split_from")]
    assert split_edges
    for u, v, data in split_edges:
        geometry = wkt.loads(data["geometry"])
        assert all(114.0 < lng < 115.0 and 30.0 < lat < 31.0
                   for lng, lat in geometry.coords)
        assert abs(geometry.coords[0][0] - fused.nodes[u]["x"]) < 1e-6
        assert abs(geometry.coords[0][1] - fused.nodes[u]["y"]) < 1e-6
        assert abs(geometry.coords[-1][0] - fused.nodes[v]["x"]) < 1e-6
        assert abs(geometry.coords[-1][1] - fused.nodes[v]["y"]) < 1e-6


def test_course_endpoint_does_not_split_a_grade_separated_osm_edge():
    graph = _base_graph()
    graph[1][2][0]["bridge"] = "yes"
    graph[1][2][0]["layer"] = "1"
    graph[2][1][0]["bridge"] = "yes"
    graph[2][1][0]["layer"] = "1"
    graph.add_node(3, x=114.3605, y=30.5305)
    feature = _feature("course:bridge-crossing", [
        [114.3605, 30.530], [114.3605, 30.5305],
    ], row=2)

    fused, migration = fuse_network(graph, [feature], _new_report([feature]))

    assert fused.number_of_edges() == graph.number_of_edges()
    assert all(data.get("course_source_id") != "course:bridge-crossing"
               for _, _, data in fused.edges(data=True))
    assert migration["course_feature_dispositions"][0]["active_release"] is False
    assert migration["course_feature_dispositions"][0]["reason"] == "insufficient_safe_anchors"


def test_ambiguous_course_match_leaves_existing_graph_unchanged():
    graph = _base_graph()
    feature = _feature("course:ambiguous", [
        [114.360, 30.530], [114.361, 30.530],
    ], row=3)
    report = {"matches": [{"source_id": "course:ambiguous", "action": "ambiguous",
                           "candidates": []}]}

    fused, migration = fuse_network(graph, [feature], report)

    assert fused.number_of_edges() == graph.number_of_edges()
    assert migration["course_feature_dispositions"][0]["reason"] == "ambiguous_correspondence"


def test_authoritative_course_rows_activate_walk_geometry_but_preserve_intentional_gap():
    graph = _base_graph()
    trusted = _feature("course:trusted-walk", [
        [114.360, 30.530], [114.361, 30.530],
    ], row=10, name="课程步行小路", road_class="electric_vehicle")
    preserved = _feature("course:preserved-gap", [
        [114.360, 30.530], [114.361, 30.530],
    ], row=393, name="自强大道", road_class="motor_vehicle")
    report = {"matches": [
        {"source_id": "course:trusted-walk", "action": "ambiguous", "candidates": []},
        {"source_id": "course:preserved-gap", "action": "matched",
         "candidates": [{"candidate_id": "track-1",
                         "edge_ids": [["1", "2", 0], ["2", "1", 0]]}]},
    ]}

    fused, migration = fuse_network(
        graph, [trusted, preserved], report,
        trusted_walk_source_rows={10, 393},
        preserved_source_rows={393},
    )

    rows = {row["source_id"]: row for row in migration["course_feature_dispositions"]}
    assert rows["course:trusted-walk"]["active_release"] is True
    assert rows["course:trusted-walk"]["match_action"] == "new_candidate"
    assert rows["course:trusted-walk"]["source_match_action"] == "ambiguous"
    course_edges = [edge for _, _, edge in fused.edges(data=True)
                    if edge.get("course_source_id") == "course:trusted-walk"]
    assert len(course_edges) == 2
    assert all(json.loads(edge["allowed_modes"]) == ["walk"] for edge in course_edges)
    assert rows["course:preserved-gap"]["active_release"] is False
    assert rows["course:preserved-gap"]["source_match_action"] == "matched"
    assert "course_source_ids" not in fused[1][2][0]
    assert nx.has_path(fused, 1, 2)


def test_trusted_dead_end_path_activates_with_one_safe_anchor():
    graph = _base_graph()
    trail = _feature("course:trusted-dead-end", [
        [114.361, 30.530], [114.362, 30.530],
    ], row=320, name="环山小路", road_class=None)
    report = {"matches": [{
        "source_id": "course:trusted-dead-end",
        "action": "ambiguous",
        "candidates": [],
    }]}

    fused, migration = fuse_network(
        graph, [trail], report,
        trusted_walk_source_rows={320},
    )

    disposition = migration["course_feature_dispositions"][0]
    assert disposition["active_release"] is True
    assert disposition["component_anchor_count"] == 1
    assert disposition["reason"] == "trusted_dead_end_connected_at_one_network_anchor"
    course_edges = [edge for _, _, edge in fused.edges(data=True)
                    if edge.get("course_source_id") == "course:trusted-dead-end"]
    assert len(course_edges) == 2


def test_short_trusted_segment_near_one_node_keeps_geometry_without_self_loop():
    graph = _base_graph()
    short_segment = _feature("course:short-segment", [
        [114.360001, 30.530], [114.3600005, 30.530],
    ], row=23, name="短步道", road_class="motor_vehicle")

    fused, migration = fuse_network(
        graph, [short_segment], _new_report([short_segment]),
        trusted_walk_source_rows={23},
    )

    disposition = migration["course_feature_dispositions"][0]
    assert disposition["active_release"] is True
    course_edges = [
        (u, v, edge)
        for u, v, edge in fused.edges(data=True)
        if edge.get("course_source_id") == "course:short-segment"
    ]
    assert len(course_edges) == 2
    assert all(u != v for u, v, _ in course_edges)
    assert all(float(edge["length"]) > 0 for _, _, edge in course_edges)
    assert all(json.loads(edge["allowed_modes"]) == ["walk"]
               for _, _, edge in course_edges)
    assert any(fused.nodes[node].get("course_source_node") == "true"
               for u, v, _ in course_edges for node in (u, v))


def test_connected_course_chain_audits_component_external_anchors():
    graph = _base_graph()
    first = _feature("course:chain-a", [[114.360, 30.530], [114.3605, 30.530]], row=4)
    second = _feature("course:chain-b", [[114.3605, 30.530], [114.361, 30.530]], row=5)
    pending = _feature("course:pending", [[114.365, 30.530], [114.365, 30.531]], row=6)

    features = [first, second, pending]
    fused, migration = fuse_network(graph, features, _new_report(features))

    assert nx.has_path(fused, 1, 2)
    rows = {row["source_id"]: row for row in migration["course_feature_dispositions"]}
    for source_id in ("course:chain-a", "course:chain-b"):
        assert rows[source_id]["active_release"] is True
        assert rows[source_id]["component_source_ids"] == ["course:chain-a", "course:chain-b"]
        assert rows[source_id]["component_anchor_count"] >= 2
        assert all(anchor["attachment"]["kind"] in {"node", "edge"}
                   for anchor in rows[source_id]["component_anchors"])
        assert all(anchor["release_node_ids"] for anchor in rows[source_id]["component_anchors"])
    assert rows["course:pending"]["active_release"] is False
    assert rows["course:pending"]["component_source_ids"] == ["course:pending"]


def _course_junction_fixture():
    graph = nx.MultiDiGraph()
    graph.add_node(1, x=114.3545774, y=30.533959)
    graph.add_node(10, x=114.3550061, y=30.5338619, course_source_node="true")
    graph.add_node(20, x=114.3545850851, y=30.5340030304, course_source_node="true")
    graph.add_node(30, x=114.3542931, y=30.5341160, course_source_node="true")
    graph.add_edge(10, 20, key=0, length=43.3, highway="footway",
                   course_source_id="course:210", course_source_ids='["course:210"]',
                   allowed_modes='["walk"]')
    graph.add_edge(20, 10, key=0, length=43.3, highway="footway",
                   course_source_id="course:210", course_source_ids='["course:210"]',
                   allowed_modes='["walk"]')
    graph.add_edge(20, 30, key=0, length=34.5, highway="footway",
                   course_source_id="course:270", course_source_ids='["course:270"]',
                   allowed_modes='["walk"]')
    graph.add_edge(30, 20, key=0, length=34.5, highway="footway",
                   course_source_id="course:270", course_source_ids='["course:270"]',
                   allowed_modes='["walk"]')
    existing_anchors = [
        {"attachment": {"kind": "node", "node_id": "100"},
         "release_node_ids": ["100"]},
        {"attachment": {"kind": "node", "node_id": "101"},
         "release_node_ids": ["101"]},
    ]
    migration = {
        "course_feature_dispositions": [
            {"source_id": "course:210", "source_row": 210,
             "active_release": True, "match_action": "new_candidate",
             "component_source_ids": ["course:210", "course:270"],
             "component_anchor_count": 2, "component_anchors": existing_anchors.copy(),
             "added_edge_ids": [["10", "20", 0], ["20", "10", 0]]},
            {"source_id": "course:270", "source_row": 270,
             "active_release": True, "match_action": "new_candidate",
             "component_source_ids": ["course:210", "course:270"],
             "component_anchor_count": 2, "component_anchors": existing_anchors.copy(),
             "added_edge_ids": [["20", "30", 0], ["30", "20", 0]]},
        ],
        "new_graph_counts": {"nodes": graph.number_of_nodes(),
                             "edges": graph.number_of_edges()},
    }
    policy = {
        "schema_version": 1,
        "overrides": [{
            "id": "course-path-to-gate",
            "course_sources": [
                {"source_id": "course:210", "source_row": 210},
                {"source_id": "course:270", "source_row": 270},
            ],
            "target_osm_node_id": "1",
            "target_osm_access": {"barrier": "gate", "foot": "yes"},
            "max_gap_m": 5.5,
            "allowed_modes": ["walk"],
            "verification_status": "source_only",
            "evidence_status": "user_confirmed_source_correlated",
            "reason": "Connect the school road source to the mapped campus gate.",
            "building_clearance_audit": {
                "snapshot_sha256": "a" * 64,
                "features_checked": 1,
                "intersections": 0,
                "nearest_building_clearance_m": 5.0,
            },
        }],
    }
    return graph, migration, policy


def test_course_junction_override_connects_verified_source_path_to_osm_gate_walk_only():
    graph, migration, policy = _course_junction_fixture()

    applied = apply_course_junction_overrides(graph, migration, policy)

    assert len(applied) == 1
    assert applied[0]["distance_m"] == pytest.approx(4.94, abs=0.02)
    assert graph.has_edge(20, 1)
    assert graph.has_edge(1, 20)
    forward = graph[20][1][0]
    reverse = graph[1][20][0]
    assert json.loads(forward["allowed_modes"]) == ["walk"]
    assert json.loads(reverse["allowed_modes"]) == ["walk"]
    assert forward["course_junction_override_id"] == "course-path-to-gate"
    assert len(migration["course_junction_overrides"]) == 1
    assert migration["new_graph_counts"] == {
        "nodes": graph.number_of_nodes(), "edges": graph.number_of_edges()
    }
    for row in migration["course_feature_dispositions"]:
        assert row["component_anchor_count"] == 3
        assert any("1" in anchor["release_node_ids"]
                   for anchor in row["component_anchors"])


def test_course_junction_override_rejects_gap_above_declared_limit_without_mutation():
    graph, migration, policy = _course_junction_fixture()
    policy["overrides"][0]["max_gap_m"] = 4.0
    before_edges = graph.number_of_edges()

    with pytest.raises(ValueError, match="exceeds the declared maximum"):
        apply_course_junction_overrides(graph, migration, policy)

    assert graph.number_of_edges() == before_edges


def test_live_yulan_gate_connects_course_path_only_in_walking_graph():
    root = Path(__file__).resolve().parents[1]
    graph = nx.read_graphml(root / "data/whu_road_network.graphml", node_type=int)
    gate_node = next(node for node in graph.nodes if str(node) == "1204194363")
    override_id = "yulan-2-gate-to-information-liberal-arts-course-path"
    override_edges = [
        (u, v, edge) for u, v, edge in graph.edges(data=True)
        if edge.get("course_junction_override_id") == override_id
    ]

    assert len(override_edges) == 2
    course_node = next(v if u == gate_node else u
                       for u, v, _ in override_edges)
    assert { (u, v) for u, v, _ in override_edges } == {
        (gate_node, course_node), (course_node, gate_node),
    }
    assert all(4.9 <= float(edge["length"]) <= 5.0
               for _, _, edge in override_edges)
    assert all(json.loads(edge["allowed_modes"]) == ["walk"]
               for _, _, edge in override_edges)

    from spatial.routing import filter_graph_for_mode
    walk_graph, _, _ = filter_graph_for_mode(graph, "walk")
    bike_graph, _, _ = filter_graph_for_mode(graph, "bike")
    drive_graph, _, _ = filter_graph_for_mode(graph, "drive")
    reference = json.loads(
        (root / "data/course_spatial_reference.geojson").read_text(encoding="utf-8")
    )
    path_source_ids = {
        feature["properties"]["source_id"]
        for feature in reference["features"]
        if feature["geometry"]["type"] == "LineString"
        and feature["properties"].get("source_row") in {210, 270}
    }
    path_nodes = set()
    for u, v, edge in graph.edges(data=True):
        raw_ids = edge.get("course_source_ids") or "[]"
        if isinstance(raw_ids, str):
            try:
                raw_ids = json.loads(raw_ids)
            except json.JSONDecodeError:
                raw_ids = [raw_ids]
        source_ids = set(map(str, raw_ids))
        if edge.get("course_source_id"):
            source_ids.add(str(edge["course_source_id"]))
        if source_ids & path_source_ids:
            path_nodes.update((u, v))

    assert path_nodes
    assert all(nx.has_path(walk_graph, gate_node, node) for node in path_nodes)
    assert all(not bike_graph.has_edge(u, v)
               for u, v, _ in override_edges)
    assert all(not drive_graph.has_edge(u, v)
               for u, v, _ in override_edges)
